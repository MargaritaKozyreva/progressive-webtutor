'use strict'
class MyH2 extends HTMLElement {
    connectedCallback() {
        let template = document.createElement('template')
        template.innerHTML = `
        <style>
            h2 {
                color: maroon !important;
                border-left: 3px solid maroon !important;
                padding: 8px 16px !important;
                font-family:'Roboto' !important;
                font-weight: 300 !important;
                font-size: 1.5em !important;
            }
        </style>
        <h2 class="cleanslate">Привет! Я заголовок внутри Shadow DOM!</h2>
        `
        ShadyCSS.prepareTemplate(template, 'my-h2')
        ShadyCSS.styleElement(this)
        this.attachShadow({
            mode: 'open'
        })
        this.shadowRoot.appendChild(document.importNode(template.content, true))
    }
}

customElements.define('my-h2', MyH2)
